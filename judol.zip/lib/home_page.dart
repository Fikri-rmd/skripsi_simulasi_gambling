import 'package:flutter/material.dart';
import 'dart:math';

class SlotGameScreen extends StatefulWidget {
  const SlotGameScreen({super.key});

  @override
  State<SlotGameScreen> createState() => _SlotGameScreenState();
}

class _SlotGameScreenState extends State<SlotGameScreen> 
    with TickerProviderStateMixin {
  int _coins = 1000;
  bool _isDisposed = false;
  List<List<String>> _columns = List.generate(4, (_) => List.filled(4, '🎰'));
  int _spinCount = 0;
  bool _isSpinning = false;
  List<AnimationController> _controllers = [];
  List<CurvedAnimation> _curvedAnimations = [];
  final List<Map<String, dynamic>> _symbolProbabilities = [
    {'symbol': '🍒', 'weight': 150, 'target': 5, 'reward': 1},
    {'symbol': '🍋', 'weight': 50, 'target': 6, 'reward': 2},
    {'symbol': '💎', 'weight': 10, 'target': 6, 'reward': 10},
    {'symbol': '💰', 'weight': 5, 'target': 4, 'reward': 30},
  ];
  final Random _random = Random();
  final int _visibleRows = 4;

 @override
  void initState() {
    super.initState();
    if (_controllers.isEmpty) {
      _controllers = List.generate(
        4,
        (index) => AnimationController(
          vsync: this,
          duration: Duration(milliseconds: 2000 + (index * 300)),
        ),
      );
      _curvedAnimations = _controllers.map((controller) 
        => CurvedAnimation(parent: controller, curve: Curves.easeOutCubic)).toList();
    }
  }

  void _resetGame() {
    setState(() {
      _coins = 1000;
      _spinCount = 0;
      _columns = List.generate(4, (_) => List.filled(4, '🎰'));
    });
  }

  Future<void> _spin() async {
    if (_coins < 5 || _isSpinning) return;

    setState(() => _isSpinning = true);
    
    final newSymbols = _generateSymbols();
    
    final animations = _controllers.asMap().entries.map((entry) async {
      final index = entry.key;
      final controller = entry.value;
      await Future.delayed(Duration(milliseconds: index * 200));
      await controller.forward(from: 0.0);
      controller.reset();
    }).toList();

    await Future.wait(animations);
    
    // Bouncing stop effect
    for (var controller in _controllers) {
      controller.animateTo(1.0, duration: const Duration(milliseconds: 500));
    }

    setState(() {
      _coins -= 5;
      _spinCount++;
      _columns = newSymbols;
      _checkWin();
      _isSpinning = false;
    });
  }

  List<List<String>> _generateSymbols() {
    final int totalWeight = _symbolProbabilities.fold(
      0, 
      (int sum, item) => sum + (item['weight'] as int)
    );
    
    return List.generate(4, (col) {
      final symbols = List.generate(20, (_) => _getRandomSymbol(totalWeight));
      return symbols.sublist(symbols.length - _visibleRows);
    });
  }

  String _getRandomSymbol(int totalWeight) {
    int randomNumber = _random.nextInt(totalWeight);
    int cumulative = 0;
    
    for (var item in _symbolProbabilities) {
      cumulative += item['weight'] as int;
      if (randomNumber < cumulative) {
        return item['symbol'] as String;
      }
    }
    return '🎰';
  }

  Widget _buildSlotColumn(int colIndex, double symbolHeight) {
    return AnimatedBuilder(
      animation: _curvedAnimations[colIndex],
      builder: (context, child) {
        return Stack(
            children: [
              Transform.translate(
                offset: Offset(0, -_curvedAnimations[colIndex].value * symbolHeight * 20),
                child: Column(
                  children: List.generate(20, (index) => 
                    Container(
                      height: symbolHeight,
                      decoration: BoxDecoration(
                        color: _getSymbolColor(_columns[colIndex][index % _visibleRows]),
                        border: Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(4), // Tambah border radius
                      ),
                      child: Center(
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 300),
                          child: Text(
                            _columns[colIndex][index % _visibleRows],
                            key: ValueKey<int>(_spinCount),
                            style: const TextStyle(fontSize: 24), // Perkecil ukuran font
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.3),
                        Colors.transparent,
                        Colors.transparent,
                        Colors.black.withOpacity(0.3),
                      ],
                      stops: const [0.0, 0.1, 0.9, 1.0],
                    ),
                  ),
                ),
              ),
            ],
        );
      },
    );
  }

  void _checkWin() {
    List<String> allSymbols = _columns.expand((col) => col).toList();
    Map<String, int> counts = _countSymbols(allSymbols);
    int totalReward = 0;
    List<String> winMessages = [];

    for (var symbol in _symbolProbabilities) {
      final String sym = symbol['symbol'] as String;
      final int target = symbol['target'] as int;
      final int reward = symbol['reward'] as int;
      
      if (counts[sym] == target && _random.nextDouble() < 0.6) {
        totalReward += reward;
        winMessages.add('$target $sym = $reward koin');
      }
    }

    if (totalReward > 0) {
      setState(() => _coins += totalReward);
      _showMessage('KOMBINASI MENANG:\n${winMessages.join('\n')}\n\nTotal Hadiah: $totalReward koin', isWin: true);
    } else {
      String lossMessage = 'Tidak ada kombinasi menang\nSisa Koin: $_coins';
      if (_spinCount % 3 == 0) {
        lossMessage += '\n\n⚠️ Peluang menang diatur secara matematis';
      }
      _showMessage(lossMessage, isWin: false);
    }
  }

  Map<String, int> _countSymbols(List<String> symbols) {
    Map<String, int> counts = {};
    for (String symbol in symbols) {
      counts[symbol] = (counts[symbol] ?? 0) + 1;
    }
    return counts;
  }

  void _showMessage(String message, {required bool isWin}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(isWin ? Icons.celebration : Icons.warning,
                color: isWin ? Colors.green : Colors.red),
            const SizedBox(width: 10),
            Text(isWin ? 'Menang!' : 'Kalah Lagi'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', 
              style: TextStyle(color: isWin ? Colors.green : Colors.red)),
          ),
        ],
      ),
    );
  }

  Color _getSymbolColor(String symbol) {
    switch (symbol) {
      case '🍒': return Colors.pink.shade100;
      case '🍋': return Colors.yellow.shade100;
      case '💎': return Colors.blue.shade100;
      case '💰': return Colors.green.shade100;
      default: return Colors.grey.shade200;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('4X4 SLOT MACHINE'),
        backgroundColor: Colors.red.shade900,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Chip(
              label: Text('$_coins 🪙', 
                style: const TextStyle(color: Colors.white)),
              backgroundColor: Colors.red.shade700,
            ),
          ),
          IconButton(
            icon: const Icon(Icons.restart_alt, color: Colors.white),
            onPressed: _resetGame,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final screenSize = MediaQuery.of(context).size;
                final squareSize = min(screenSize.width, screenSize.height) * 0.7; // 7
                final symbolHeight = squareSize / _visibleRows;
                return Center(
                  child: Container(
                    width: squareSize,
                    height: squareSize,
                    margin: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.red.shade800, width: 3),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(4, (index) => 
                        Flexible(
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4.0), // Spasi antar kolom
                          child: AspectRatio(
                              aspectRatio: 1/4, // Tinggi 4x lebar
                              child: _buildSlotColumn(index, symbolHeight),
                            ),
                     ),
                  ),
                ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: ElevatedButton.icon(
              icon: const Icon(Icons.casino, size: 30),
              label: const Text('PUTAR - 5 KOIN',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade800,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25)),
              ),
              onPressed: _isSpinning ? null : _spin,
            ),
          ),
          Container(
            color: Colors.red.shade50,
            padding: const EdgeInsets.all(12),
            child: const Text(
              'SETIAP KOLOM MEMILIKI 4 BARIS YANG BERPUTAR VERTIKAL\n'
              'MENANG DENGAN KOMBINASI TERTENTU - HANYA SIMULASI!',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.red, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

@override
  void dispose() {
    if (!_isDisposed) {
      for (var controller in _controllers) {
        controller.dispose();
      }
      _isDisposed = true;
    }
    super.dispose();
  }
}